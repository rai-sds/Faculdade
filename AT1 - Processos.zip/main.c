#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "processo.h"

int main() {

  Processo *dados = LerArquivo("processo_043_202409032338.csv", QNT_LINHAS);

  //Modelo de ordenação
  // OrdenarPorId(dados, QNT_LINHAS);
  // SalvarEmCsv("ordenado_por_id.csv", dados, QNT_LINHAS);

  // OrdenarPorData(dados, QNT_LINHAS);
  // SalvarEmCsv("ordenado_por_data.csv", dados, QNT_LINHAS);

  //Consulta
  // int IdParaBuscar = 11531;
  // int Total = ContarPorIdClasse(dados, QNT_LINHAS, IdParaBuscar);
  // printf("Total de processos por IdClasse %d: %d\n", IdParaBuscar, Total);

  // Total de IdAssunto na base
  // int TotalAssuntos = ContarPorIdAssunto(dados, QNT_LINHAS);
  // printf("Total de IdAssuntos distintos: %d\n", TotalAssuntos);

  // Processo com mais de 1 assunto
  // ListarMultiplosAssuntos(dados, QNT_LINHAS);
  
  // Dias em tramitação
  // for (int i = 0; i < QNT_LINHAS; i++) {
  //   int dias = DiasEmTramitacao(dados[i].DataAjuizamento);
  //   printf("ID: %d | Data: %s | Dias em tramitação: %d\n",
  //     dados[i].Id, dados[i].DataAjuizamento, dias);
  // }
  // free(dados);
  // return 0;
}