
import React from 'react';
import { View, Text, TextInput, Image, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/Feather';

export default function LoginScreen() {
  return (
    <View style={styles.container}>
      <Image source={require('../assets/logo.png')} style={styles.logo} />
      <View style={styles.inputContainer}>
        <Icon name="mail" size={20} color="#9e9e9e" style={styles.icon} />
        <TextInput placeholder="Email" style={styles.input} placeholderTextColor="#9e9e9e" />
      </View>
      <View style={styles.inputContainer}>
        <Icon name="lock" size={20} color="#9e9e9e" style={styles.icon} />
        <TextInput placeholder="Senha" style={styles.input} secureTextEntry placeholderTextColor="#9e9e9e" />
      </View>
      <TouchableOpacity>
        <Text style={styles.forgotText}>ESQUECEU MINHA SENHA</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.loginButton}>
        <Text style={styles.loginText}>ENTRAR</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.createAccountButton}>
        <Text style={styles.createAccountText}>CRIAR CONTA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f6f1',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  logo: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
    marginBottom: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 25,
    alignItems: 'center',
    paddingHorizontal: 15,
    marginBottom: 15,
    width: '100%',
    elevation: 3,
  },
  input: {
    flex: 1,
    paddingVertical: 12,
    paddingLeft: 10,
    fontSize: 16,
    color: '#333',
  },
  icon: {
    marginRight: 5,
  },
  forgotText: {
    color: '#5a945c',
    alignSelf: 'flex-end',
    marginBottom: 25,
    fontSize: 12,
  },
  loginButton: {
    backgroundColor: '#5a945c',
    borderRadius: 25,
    width: '100%',
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  loginText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  createAccountButton: {
    borderColor: '#5a945c',
    borderWidth: 1,
    borderRadius: 25,
    width: '100%',
    paddingVertical: 12,
    alignItems: 'center',
  },
  createAccountText: {
    color: '#5a945c',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
