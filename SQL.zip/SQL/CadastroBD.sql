CREATE SCHEMA CADASTRO;

USE CADASTRO;

CREATE TABLE USER
(
	idUser INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
	nameUser VARCHAR(45) NOT NULL,
	emailUser VARCHAR(45) NOT NULL

);

INSERT INTO USER (nameUser, emailUser)
VALUES 
("Adam", "adam@gmail.com"),
("José", "jose@gmail.com"),
("Maria", "maria@gmail.com");
