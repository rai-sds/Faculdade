package Cadastro_Usuario;

import java.util.List;
import Cadastro_Usuario.models.User;
import Cadastro_Usuario.dao.UserDAO;
import Cadastro_Usuario.dao.UserDaoImpl;

public class Main
{

	public static void main(String[] args)
	{
		UserDAO userDao = new UserDaoImpl();

		List<User> users = userDao.getAllUsers();
		for(User user : users)
		{
			System.out.println("ID: "+user.getId() + ", Name: "+user.getName()+", Email: "+user.getEmail());
		}

		User user = userDao.getUser(2);
		System.out.println("ID: "+user.getId() + ", Name: "+user.getName()+", Email: "+user.getEmail());

		user.setEmail("email@exemple.com");
		userDao.updateUser(user);

		//userDao.deleteUser(user);

	}


}