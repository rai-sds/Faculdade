package Cadastro_Usuario.dao;

import java.util.List;
import Cadastro_Usuario.models.User;

public interface UserDAO
{
	public List<User> getAllUsers();
	public User getUser(int id);
	public void updateUser(User user);
	public void deleteUser(User user);


}