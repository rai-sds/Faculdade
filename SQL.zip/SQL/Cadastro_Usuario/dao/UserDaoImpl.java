package Cadastro_Usuario.dao;


import java.sql.PreparedStatement; // Importar PreparedStatement
import java.sql.Statement;
import java.sql.ResultSet; // Importar ResultSet
import java.util.List;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.Connection;
import Cadastro_Usuario.models.User;
import Cadastro_Usuario.util.DBConnection;


public class UserDaoImpl implements UserDAO
{

	private Connection conn;

	public UserDaoImpl()
	{
		conn = DBConnection.getConnection();
	}

	public List<User> getAllUsers()
	{
		List<User> users = new ArrayList<User>();

		try
		{
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM USER");
			
			while(rs.next())
			{
				User user = new User();
				user.setId(rs.getInt("idUser"));
				user.setName(rs.getString("nameUser"));
				user.setEmail(rs.getString("emailUser"));
				users.add(user);
	
			}
		}catch(SQLException e)
		{
			throw new RuntimeException(e);
		}

		return users;
	}

	public User getUser(int id)
	{
		User user = new User();
	
		try
		{
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM USER WHERE idUser=?");
			ps.setInt(1,id);
			ResultSet rs = ps.executeQuery();

			if(rs.next())
			{
				user.setId(rs.getInt("idUser"));
				user.setName(rs.getString("nameUser"));
				user.setEmail(rs.getString("emailUser"));
			}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}

		return user;

	}


	public void updateUser(User user)
	{

		try
		{
			PreparedStatement ps = conn.prepareStatement("UPDATE USER SET nameUser=?, emailUser=? WHERE idUser=?");
			ps.setString(1,user.getName());
			ps.setString(2,user.getEmail());
			ps.setInt(3,user.getId());
			ps.executeUpdate();

			
		}catch(SQLException e)
		{
			e.printStackTrace();
		}


	}

	public void deleteUser(User user)
	{
		try
		{
			PreparedStatement ps = conn.prepareStatement("DELETE FROM USER WHERE idUser=?");
			ps.setInt(1, user.getId());
			ps.executeUpdate();

		}catch(SQLException e)
		{	
			e.printStackTrace();
		}

	}


}