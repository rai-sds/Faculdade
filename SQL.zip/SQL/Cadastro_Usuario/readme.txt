O projeto Cadastro_Usuario deve ser salvo dentro de uma pasta no diretório do seu computador. Vejam como o projeto está organizado: 

myproject/
    Cadastro_Usuario/
      dao/
        UserDAO.java
        UserDaoImpl.java
      models/
        User.java
      util/
        DBConnection.java
        mysql-connector-j-8.4.0.jar
      Main.java


Para compilar pelo prompt, navegue até a pasta myproject e escreva:


javac -cp src/Cadastro_Usuario/util/mysql-connector-j-8.4.0.jar -d out src/Cadastro_Usuario/Main.java src/Cadastro_Usuario/models/*.java src/Cadastro_Usuario/dao/*.java src/Cadastro_Usuario/util/*.java

Execute o código assim:

java -cp out:src/Cadastro_Usuario/util/mysql-connector-j-8.4.0.jar Cadastro_Usuario.Main

Certique-se que o arquivo JAR do mySQL está com esse nome mesmo e dentro da pasta util.




	