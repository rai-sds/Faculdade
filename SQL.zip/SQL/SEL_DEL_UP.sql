CREATE SCHEMA INDUSTRIA;

USE INDUSTRIA;

CREATE TABLE DDD
(
	codDDD INT AUTO_INCREMENT PRIMARY KEY,
    numDDD CHAR(3) NOT NULL,
    regiaoDDD VARCHAR(45) NOT NULL

);

CREATE TABLE FORNECEDOR
(
	numFornecedor INT AUTO_INCREMENT PRIMARY KEY,
	nomeFornecedor VARCHAR(100) NOT NULL
);

CREATE TABLE DEPARTAMENTO
(
	numDepart INT AUTO_INCREMENT PRIMARY KEY,
    setorDepart VARCHAR(45) NOT NULL

);

CREATE TABLE FUNCIONARIO
(
	numFunc INT AUTO_INCREMENT PRIMARY KEY,
    nomeFunc VARCHAR(100) NOT NULL,
    salariFunc DECIMAL(7,2) NOT NULL,
	numDepart INT NOT NULL,
    dataInicioFunc DATE NOT NULL,
	CONSTRAINT FUNCIONARIO_DEPARTAMENTO
		FOREIGN KEY (numDepart)
		REFERENCES DEPARTAMENTO (numDepart)
);

CREATE TABLE TELEFONE
(
	codTelefone INT AUTO_INCREMENT PRIMARY KEY,
    numTelefone VARCHAR(20),
	codDDD INT NOT NULL,
    numFornecedor INT,
    numFunc INT,
    CONSTRAINT FORNECEDOR_TELEFONE
		FOREIGN KEY (numFornecedor)
		REFERENCES FORNECEDOR (numFornecedor),
    CONSTRAINT DDDTELEFONE
		FOREIGN KEY (codDDD) 
        REFERENCES DDD(codDDD),
	CONSTRAINT FUNCIONARIO_TELEFONE
		FOREIGN KEY (numFunc)
		REFERENCES FUNCIONARIO (numFunc)
);


CREATE TABLE PROJETO
(
	numProjeto INT AUTO_INCREMENT PRIMARY KEY,
    orcaProjeto DECIMAL(8,2)
);

CREATE TABLE FUNCIONARIO_PROJETO
(
	codFunc INT  AUTO_INCREMENT PRIMARY KEY,
    numFunc INT NOT NULL,
    numProjeto INT NOT NULL,
    dataInicioProjeto DATE,
    horasTrabalhadas FLOAT,
	CONSTRAINT FUNCIONARIO
		FOREIGN KEY (numFunc)
		REFERENCES FUNCIONARIO (numFunc),
    CONSTRAINT PROJETO
		FOREIGN KEY (numProjeto)
		REFERENCES PROJETO (numProjeto)
);

CREATE TABLE DEPOSITO
(
	numDeposito INT AUTO_INCREMENT PRIMARY KEY,
    nomeDeposito VARCHAR(100) NOT NULL
);


CREATE TABLE ENDERECO(
	codEndereco INT AUTO_INCREMENT PRIMARY KEY,
    lograEndereco VARCHAR(45) NOT NULL,
    numEndereco INT NOT NULL,
    cidadeEndereco VARCHAR(45) NOT NULL,
    estadoEndereco VARCHAR(45) NOT NULL,
	numFornecedor INT,
    numDeposito INT,
    CONSTRAINT ENDERECO_FORNECEDOR
		FOREIGN KEY (numFornecedor)
		REFERENCES FORNECEDOR (numFornecedor),
    CONSTRAINT ENDERECO_DEPOSITO
		FOREIGN KEY (numDeposito)
		REFERENCES DEPOSITO (numDeposito)
);

CREATE TABLE PECA
(
	numPeca INT AUTO_INCREMENT PRIMARY KEY,
    pesoPeca FLOAT NOT NULL,
    corPeca VARCHAR(45) NOT NULL,
    numDeposito INT NOT NULL,
    CONSTRAINT PECA_DEPOSITO
		FOREIGN KEY (numDeposito)
		REFERENCES DEPOSITO (numDeposito),
    CONSTRAINT CHECK_PESO
		CHECK (pesoPeca>0)
);

CREATE TABLE PECA_FORNECEDOR
(
	codPecaFor INT AUTO_INCREMENT PRIMARY KEY,
    numFornecedor INT NOT NULL,
    numPeca INT NOT NULL,
    CONSTRAINT PECA
		FOREIGN KEY (numPeca)
		REFERENCES PECA (numPeca),
    CONSTRAINT FORNECEDOR
		FOREIGN KEY (numFornecedor)
		REFERENCES FORNECEDOR (numFornecedor)
);

CREATE TABLE FORNECEDOR_PROJETO
(
	codForProj INT AUTO_INCREMENT PRIMARY KEY,
    numFornecedor INT NOT NULL,
    numProjeto INT NOT NULL,
    nomeMaterial VARCHAR(100) NOT NULL,
    qtdMaterial INT NOT NULL,
    CONSTRAINT PROJETO_FORN
		FOREIGN KEY (numProjeto)
		REFERENCES PROJETO (numProjeto),
    CONSTRAINT FORNECEDOR_PROJ
		FOREIGN KEY (numFornecedor)
		REFERENCES FORNECEDOR (numFornecedor)
);

-- Inserindo dados na tabela
INSERT INTO DDD (numDDD, regiaoDDD) VALUES
(11, 'São Paulo'),
(21, 'Rio de Janeiro'),
(31, 'Belo Horizonte'),
(41, 'Curitiba'),
(51, 'Porto Alegre'),
(61, 'Brasília'),
(71, 'Salvador'),
(81, 'Recife'),
(91, 'Belém'),
(12, 'Santos'),
(22, 'Niterói'),
(32, 'Juiz de Fora'),
(42, 'Londrina'),
(52, 'Caxias do Sul'),
(62, 'Goiânia'),
(72, 'Vitória da Conquista'),
(82, 'Maceió'),
(92, 'Manaus');

INSERT INTO FORNECEDOR (nomeFornecedor) VALUES 
('Fornecedor A'),
('Fornecedor B'),
('Fornecedor C'),
('Fornecedor D'),
('Fornecedor E'),
('Fornecedor F'),
('Fornecedor G'),
('Fornecedor H');

INSERT INTO DEPARTAMENTO (setorDepart) VALUES 
('Recursos Humanos'),
('Desenvolvimento'),
('Marketing'),
('Logística'),
('Financeiro'),
('Qualidade'),
('TI'),
('Vendas'),
('Produção');

INSERT INTO FUNCIONARIO (nomeFunc, salariFunc, numDepart, dataInicioFunc) VALUES 
('João Silva', 5000.00, 1, '2023-01-15'), -- Recursos Humanos
('Maria Santos', 6000.00, 2, '2022-07-20'), -- Desenvolvimento
('Carlos Oliveira', 5500.00, 3, '2022-11-10'), -- Marketing
('Ana Costa', 5200.00, 4, '2023-03-05'), -- Logística
('Pedro Almeida', 5800.00, 5, '2022-09-28'), -- Financeiro
('Laura Pereira', 5300.00, 6, '2023-02-10'), -- Qualidade
('Rafael Martins', 6200.00, 7, '2022-06-15'), -- TI
('Julia Ferreira', 5700.00, 8, '2023-04-03'), -- Vendas
('Marcelo Santos', 5400.00, 9, '2022-12-20'); -- Produção

INSERT INTO TELEFONE (numTelefone, codDDD, numFornecedor, numFunc) VALUES 
('123456789', 1, 1,NULL), 
('987654321', 2, 2,NULL), 
('456789123', 3, NULL,3),
('654123789', 3, NULL,4), 
('321789456', 4, NULL,5), 
('789456123', 5, 5,NULL),  
('654321987', 1, 7,NULL), 
('321987654', 6, NULL,7), 
('987456321', 9, 7,NULL); 

INSERT INTO PROJETO (orcaProjeto) VALUES 
(5000.00), -- Projeto 1
(10000.00), -- Projeto 2
(7500.00), -- Projeto 3
(12000.00), -- Projeto 4
(9000.00); -- Projeto 5



INSERT INTO FUNCIONARIO_PROJETO (numFunc, numProjeto, dataInicioProjeto, horasTrabalhadas) 
VALUES (1, 1, '2024-01-10', 40),
		(2, 2, '2024-02-15', 35),
        (3, 3, '2024-03-20', 45),
        (4, 4, '2024-04-25', 50),
        (5, 5, '2024-05-30', 48);

-- Inserindo dados criativos no Depósito
INSERT INTO DEPOSITO (nomeDeposito) VALUES 
('Depósito Central'),
('Depósito Norte'),
('Depósito Sul'),
('Depósito Leste'),
('Depósito Oeste');

-- Inserir vários endereços relacionados com fornecedores e depósitos em uma única consulta
INSERT INTO ENDERECO (lograEndereco, numEndereco, cidadeEndereco, estadoEndereco, numFornecedor, numDeposito)
VALUES 
    ('Rua A', 123, 'São Paulo', 'SP', 1, NULL),  -- Endereço relacionado com fornecedor (numFornecedor = 1)
    ('Av. B', 456, 'Rio de Janeiro', 'RJ', 2, NULL),  -- Endereço relacionado com fornecedor (numFornecedor = 2)
    ('Rua C', 789, 'Belo Horizonte', 'MG', NULL, 1),  -- Endereço relacionado com depósito (numDeposito = 1)
    ('Rua D', 1011, 'Curitiba', 'PR', NULL, 2);  -- Endereço relacionado com depósito (numDeposito = 2)

-- Inserir vários dados de forma criativa na tabela PECA relacionando-os com a tabela DEPOSITO
INSERT INTO PECA (pesoPeca, corPeca, numDeposito)
VALUES
    (12.5, 'Vermelha', 1), -- NumDeposito 1 corresponde ao Depósito A
    (8.0, 'Verde', 2),     -- NumDeposito 2 corresponde ao Depósito B
    (15.3, 'Azul', 3),     -- NumDeposito 3 corresponde ao Depósito C
    (9.2, 'Amarela', 4),   -- NumDeposito 4 corresponde ao Depósito D
    (11.0, 'Roxa', 5);     -- NumDeposito 5 corresponde ao Depósito E

-- Inserir vários dados na tabela PECA_FORNECEDOR relacionando com fornecedor e peça
INSERT INTO PECA_FORNECEDOR (numFornecedor, numPeca)
VALUES
    (1, 1),  -- NumFornecedor 1 corresponde ao Fornecedor A e NumPeca 1 corresponde à primeira peça
    (2, 2),  -- NumFornecedor 2 corresponde ao Fornecedor B e NumPeca 2 corresponde à segunda peça
    (3, 3),  -- NumFornecedor 3 corresponde ao Fornecedor C e NumPeca 3 corresponde à terceira peça
    (4, 4),  -- NumFornecedor 4 corresponde ao Fornecedor D e NumPeca 4 corresponde à quarta peça
    (5, 5),  -- NumFornecedor 5 corresponde ao Fornecedor E e NumPeca 5 corresponde à quinta peça
    (6, 1),  -- NumFornecedor 6 corresponde ao Fornecedor F e NumPeca 1 corresponde à primeira peça
    (7, 2),  -- NumFornecedor 7 corresponde ao Fornecedor G e NumPeca 2 corresponde à segunda peça
    (8, 3),  -- NumFornecedor 8 corresponde ao Fornecedor H e NumPeca 3 corresponde à terceira peça
    (2, 4),  -- NumFornecedor 2 corresponde ao Fornecedor B e NumPeca 4 corresponde à quarta peça
    (1, 5);  -- NumFornecedor 1 corresponde ao Fornecedor A e NumPeca 5 corresponde à quinta peça

-- Inserir vários dados na tabela FORNECEDOR_PROJETO relacionando com projeto e fornecedor
INSERT INTO FORNECEDOR_PROJETO (numFornecedor, numProjeto, nomeMaterial, qtdMaterial)
VALUES
    (1, 1, 'Material A', 100),   -- NumFornecedor 1 corresponde ao Fornecedor A e NumProjeto 1 corresponde ao primeiro projeto
    (2, 2, 'Material B', 200),   -- NumFornecedor 2 corresponde ao Fornecedor B e NumProjeto 2 corresponde ao segundo projeto
    (3, 3, 'Material C', 150),   -- NumFornecedor 3 corresponde ao Fornecedor C e NumProjeto 3 corresponde ao terceiro projeto
    (4, 1, 'Material D', 300),   -- NumFornecedor 4 corresponde ao Fornecedor D e NumProjeto 1 corresponde ao primeiro projeto
    (5, 2, 'Material E', 250),   -- NumFornecedor 5 corresponde ao Fornecedor E e NumProjeto 2 corresponde ao segundo projeto
    (6, 3, 'Material F', 200),   -- NumFornecedor 6 corresponde ao Fornecedor F e NumProjeto 3 corresponde ao terceiro projeto
    (7, 1, 'Material G', 150),   -- NumFornecedor 7 corresponde ao Fornecedor G e NumProjeto 1 corresponde ao primeiro projeto
    (8, 2, 'Material H', 100),   -- NumFornecedor 8 corresponde ao Fornecedor H e NumProjeto 2 corresponde ao segundo projeto
    (1, 3, 'Material I', 50),    -- NumFornecedor 1 corresponde ao Fornecedor A e NumProjeto 3 corresponde ao terceiro projeto
    (3, 1, 'Material J', 75);   -- NumFornecedor 3 corresponde ao Fornecedor C e NumProjeto 1 corresponde ao primeiro projeto
    
    
SELECT * FROM FORNECEDOR;

SELECT * FROM PROJETO;

SELECT nomeFunc,salariFunc FROM FUNCIONARIO;

SELECT f.nomeFornecedor, COUNT(fp.codPecaFor) AS quantidade_material
FROM FORNECEDOR f
LEFT JOIN PECA_FORNECEDOR fp ON f.numFornecedor = fp.numFornecedor
GROUP BY f.nomeFornecedor;

SELECT t.numTelefone
FROM TELEFONE t
INNER JOIN DDD d ON t.codDDD = d.codDDD
WHERE d.numDDD = 11;

UPDATE FUNCIONARIO
SET salariFunc = 5500.00
WHERE nomeFunc = 'João Silva';

SELECT f.nomeFunc, d.setorDepart
FROM FUNCIONARIO f
INNER JOIN DEPARTAMENTO d ON f.numDepart = d.numDepart;


SELECT AVG(salariFunc) AS media_salario
FROM FUNCIONARIO;

SELECT t.numTelefone
FROM TELEFONE t
INNER JOIN DDD d ON t.codDDD = d.codDDD
WHERE d.regiaoDDD = 'São Paulo';

SELECT *
FROM PROJETO
ORDER BY orcaProjeto DESC
LIMIT 1;

SELECT f.nomeFornecedor
FROM FORNECEDOR f
INNER JOIN PECA_FORNECEDOR pf ON f.numFornecedor = pf.numFornecedor
GROUP BY f.nomeFornecedor
HAVING COUNT(DISTINCT pf.numPeca) > 1;

UPDATE FUNCIONARIO, DEPARTAMENTO
SET setorDepart = 'Desenvolvimento de Software'
WHERE FUNCIONARIO.nomeFunc = 'Maria Santos'
AND DEPARTAMENTO.numDepart = FUNCIONARIO.numDepart;

UPDATE ENDERECO
SET numDeposito = 5
WHERE codEndereco = 3;

DELETE FROM FUNCIONARIO_PROJETO
WHERE numFunc  IN (SELECT numFunc FROM FUNCIONARIO WHERE dataInicioFunc < '2022-12-31' );

DELETE FROM TELEFONE
WHERE numFunc IN (SELECT numFunc FROM FUNCIONARIO WHERE dataInicioFunc< '2022-12-31');

DELETE FROM FUNCIONARIO
WHERE dataInicioFunc < '2022-12-31';

DELETE FROM PECA_FORNECEDOR
WHERE numFornecedor = (SELECT numFornecedor FROM FORNECEDOR WHERE nomeFornecedor = 'Fornecedor B');

DELETE FROM ENDERECO
WHERE numFornecedor NOT IN (SELECT DISTINCT numFornecedor FROM PECA_FORNECEDOR);

DELETE FROM FORNECEDOR_PROJETO
WHERE numFornecedor NOT IN (SELECT DISTINCT numFornecedor FROM PECA_FORNECEDOR);

DELETE FROM FORNECEDOR
WHERE numFornecedor NOT IN (SELECT DISTINCT numFornecedor FROM PECA_FORNECEDOR);

